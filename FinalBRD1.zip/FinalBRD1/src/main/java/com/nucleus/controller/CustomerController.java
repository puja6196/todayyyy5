package com.nucleus.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.Customer;
import com.nucleus.service.ServiceCustomerI;

@Controller
@SessionAttributes("username")

public class CustomerController 
 {
	
	@Autowired
	ServiceCustomerI serviceCustomer;
	@ModelAttribute("customer")
	
	public Customer customer()
	{
		return new Customer();
	}
	
	@ModelAttribute("username")
	public String username()
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String username=auth.getName();
		return username;
	
	}
	
	@RequestMapping(value="/show")
	public ModelAndView addnew(){
		List<Customer> list=serviceCustomer.viewMultiple();
		return new ModelAndView("show","multiple",list);
	}
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String addHandler()
	{
		return "add";
	}
	@RequestMapping("/link")
	
	public ModelAndView loginHandler()
	     {
		  List<Customer> list=serviceCustomer.viewMultiple();
		  return new ModelAndView("link","multiple",list);
		
	    }
   @RequestMapping(value="/addcustomercode",method=RequestMethod.POST )
    public ModelAndView addCustomer(@RequestParam("code") String cCode){
		int result=serviceCustomer.isUniqueCustomer(cCode);
		if(result!=0)
		{
			return new ModelAndView("addcustomer","code",cCode);
		}
		return new ModelAndView("customeralreadyexist");
	}
	
	@RequestMapping(value="/added", method=RequestMethod.POST)
	public ModelAndView added(@ModelAttribute("customercreate")Customer cust, @Valid BindingResult bind)
	{
		cust.setCreateDate(new Date());
		cust.setModifiedDate(new Date());
		/*if(bind.hasErrors())
			return new ModelAndView("addcustomer");*/
		/*else{*/
	
			int result=serviceCustomer.addCustomer(cust);
			if(result!=0)
				return new ModelAndView("addedsuccessfully");
			 return new ModelAndView("notadded");
		/*}*/
	}
	@RequestMapping(value="/single", method=RequestMethod.GET)
	public String viewSingle()
	{
		return "singleViewCode";
	}
	
	@RequestMapping(value="/viewcustomer",method=RequestMethod.POST)
	
	
	
	public ModelAndView viewCustomer(@RequestParam("code") String cCode)
	
	{
		
		     Customer customer=serviceCustomer.viewSingle(cCode);
		
		   if(customer!=null)
			
		  return new ModelAndView("viewSingleCustomer","customer",customer);
		  return new ModelAndView("customerdoesnotexist","customer",customer);
	     }
	
	
	@RequestMapping(value="/multiple", method=RequestMethod.GET)
	public ModelAndView viewMultiple()
	{
		List<Customer> list=serviceCustomer.viewMultiple();
		return new ModelAndView("viewMultipleCustomer","multiple",list);
	}
	//////////////task/////////
	
	@RequestMapping(value="/createbydate", method=RequestMethod.GET)
	public String createbydate()
	 {
		
		
		
		
		return "createbycode";
		
	}
    
	@RequestMapping(value="/createbydate",method=RequestMethod.POST)
	 
	public ModelAndView createbydate(@RequestParam("code") String cCode)
       
	{
          
		Customer customer=serviceCustomer.viewSingle(cCode);
		   
          if(customer!=null)
			
			   
			   return new ModelAndView("viewSingleCustomer","customer",customer);
		   
		  
		   return new ModelAndView("customerdoesnotexist");
	
       }  
	
	        /////////////
	@RequestMapping(value="/update", method=RequestMethod.GET)
	public String update()
	{
		
		return "updateCode";
	}
	@RequestMapping(value="/updatecode",method=RequestMethod.POST )
	public ModelAndView updateCustomerCode(@RequestParam("customercode") String cCode){
		Customer customer=serviceCustomer.viewSingle(cCode);
		if(customer!=null)
			return new ModelAndView("updateCustomer","data",customer);
		return new ModelAndView("customerdoesnotexist");
	}
	@RequestMapping(value="/updated",method=RequestMethod.POST)
	public String updated(@ModelAttribute("customerupdate") Customer cus, BindingResult bind){
		/*if(bind.hasErrors())
			return "updateCustomer";
		else{*/
			int result=serviceCustomer.updateCustomer(cus);
			if(result!=0)
				return "updatedsuccessfully";
			return "notupdated";
		}		
	/*}*/
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String delete()
	{
		return "delete";
	}
	@RequestMapping(value="/deletecustomer", method=RequestMethod.POST)
	public String deleteCustomer(@RequestParam("customercode") String cCode)
	{
		int code=Integer.parseInt(cCode.trim());
		int result=serviceCustomer.deleteCustomer(code);
		if(result!=0)
			return "deletedsuccessfully";
		    return "customerdoesnotexist";	
	}
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout()
	
	{
		
		return "logout";
	
	}

 
 
 }
