package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class SecurityController {
	@RequestMapping("/")
	public String blankHandler()
	{
		return "login";
	}
	@RequestMapping("/home")
	public String home(){
		return "home";
	}
	@RequestMapping("/error")
	public String errorHandler()
	{
		return "errorpage";
	}
	@RequestMapping("/accessdenied")
	public String accessDeniedHandler()
	{
		return "accessdenied";
	}
	@RequestMapping("/logoutpage")
	public String logoutHandler()
	{
		return "login";
	}
}
