package com.nucleus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.Customer;
import com.nucleus.pojo.Role;
import com.nucleus.pojo.User;
import com.nucleus.service.ServiceUserI;

@Controller
public class UserController {
	
	@Autowired
	ServiceUserI serviceUser;
	@ModelAttribute("role")
	public Role role(){
		return new Role();
	}
	@ModelAttribute("user")
	public User user(){
		return new User();
	}
	
	@RequestMapping(value="/addadmin", method=RequestMethod.GET)
	public String underConstruction(){
		return "addadmin"; 
	}

	@RequestMapping(value="/addusercode", method=RequestMethod.POST)
	public ModelAndView addusercode(@RequestParam("code") String code){
		int id= Integer.parseInt(code);
		int result=serviceUser.addUser(id);
		if(result!=0)
			return new ModelAndView("admin","id",id);
		return new ModelAndView("useralreadyexist");
	}
	@RequestMapping(value="/useradded", method=RequestMethod.POST)
	public String useradded(@ModelAttribute("user") User user){
		if(user.getRoleid()==1001 || user.getRoleid()==1002){
			int result=serviceUser.addedUser(user);
			if(result!=0)
				return "useraddedsuccessfully";
			return "usernotadded";
		}
		else
			return "invalidroleid";
		
	}
	@RequestMapping(value="/roleid" , method=RequestMethod.GET)
	public String roleid(@ModelAttribute("role") Role role,@RequestParam("userid") String userid/*,@ModelAttribute("user") User user*/){
		int user=Integer.parseInt(userid);
		System.out.println(role);
		int result=serviceUser.updateUser(role, user);
		if(result!=0)
			return "useraddedsuccessfully";
		return "usernotadded";
	}
	@RequestMapping(value="/viewuser", method=RequestMethod.GET)
	public ModelAndView viewUser(){
		List<User> user=serviceUser.viewUser();
		return new ModelAndView("viewuser","viewuser",user);
	}
}
