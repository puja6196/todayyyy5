package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.Customer;

public interface CustomerDaoI {
	public int addCustomer(Customer cust);
	public int isUniqueCustomer(String code);
	public Customer viewSingle(String code);
	public List<Customer> viewMultiple();
	public int deleteCustomer(int code);
	public int updateCustomer(Customer cus);
}
