package com.nucleus.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.pojo.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDaoI {

	Logger log = Logger.getLogger(CustomerDaoImpl.class);
	@Autowired
     private SessionFactory sessionFactory; 
	
	static int i;
	@Override
	public int addCustomer(final Customer cus) {
		Serializable s=sessionFactory.getCurrentSession().save(cus);
		if(s!=null)
			return 1;
		return 0;
	}
	@Override
	public int isUniqueCustomer(final String code) 
	{
		Customer user=(Customer) sessionFactory.getCurrentSession().get(com.nucleus.pojo.Customer.class, code);
		if(user!=null)
			return 0;
		return 1;
	}
	@Override
	public Customer viewSingle(final String code) {
		Customer user=(Customer) sessionFactory.getCurrentSession().get(com.nucleus.pojo.Customer.class, code);
		return user;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> viewMultiple() {
		Query query=sessionFactory.getCurrentSession().createQuery("from Customer");
		List<Customer> list=query.list();
		return list;
	}
	
	@Override
	public int updateCustomer(final Customer cus) {
		Query query=sessionFactory.getCurrentSession().createQuery("update Customer c set c.customerName=?,c.address=?,c.pincode=?,c.email=?,c.contactNum=?,c.modifiedDate=? where c.customerCode=?");
		query.setParameter(0, cus.getCustomerName());
		query.setParameter(1, cus.getAddress());
		query.setParameter(2, cus.getPincode());
		query.setParameter(3, cus.getEmail());
		query.setParameter(4, cus.getContactNum());
		query.setParameter(5, new Date());
	
		query.setParameter(6, cus.getCustomerCode());
		int result=query.executeUpdate();
		return result;
	}
	@Override
	public int deleteCustomer(int code) {
		Session session=sessionFactory.getCurrentSession();
		
		Customer cus=(Customer) session.get(com.nucleus.pojo.Customer.class,String.valueOf(code));
		if(cus!=null){
			session.delete(cus);
			return 1;
		}
		return 0;
	}
}
