package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.Role;
import com.nucleus.pojo.User;

public interface UserDaoI {
	public int addUser(int id);
	public int addedUser(User user);
	public List<User> viewUser();
	public int updateUser(Role roleid, int userid);
}
