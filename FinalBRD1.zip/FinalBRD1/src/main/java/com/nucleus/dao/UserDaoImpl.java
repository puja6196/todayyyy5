package com.nucleus.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.pojo.Role;
import com.nucleus.pojo.User;

@Repository
public class UserDaoImpl implements UserDaoI 
{
	
	@Autowired
	private SessionFactory sessionFactory; 
	public int addUser(int id) 
	{
	
	User user=(User) sessionFactory.getCurrentSession().get(com.nucleus.pojo.User.class, id);
	if(user!=null)
			return 0;
		return 1;
	}

	@Override
	public int addedUser(User user) {
	
		Serializable s=sessionFactory.getCurrentSession().save(user);
		if(s!=null)
			return 1;
		return 0;
	}

	@Override
	public List<User> viewUser() {
		Query query=sessionFactory.getCurrentSession().createQuery("from User");
		@SuppressWarnings("unchecked")
		List<User> list=query.list();
		for(User u:list){
			System.out.println(u);
		}
		return list;
	}

	@Override
	public int updateUser(Role role, int userid) {
		Query query=sessionFactory.getCurrentSession().createQuery("update User u set ROLEID=? WHERE USERID=?");
		query.setParameter(0,Integer.parseInt(role.getROLEID()));
		query.setParameter(1,userid);
		int result=query.executeUpdate();
		System.out.println(result);
		return result;
	}

}
