package com.nucleus.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.pojo.Customer;

@SuppressWarnings("rawtypes")
public class CustomerMapper implements RowMapper
{
        @Override
	    public Object mapRow(ResultSet rs, int arg1) throws SQLException 
	    {
		Customer cus=new Customer();
		cus.setCustomerCode(rs.getString(1));
		cus.setCustomerName(rs.getString(2));
		cus.setAddress(rs.getString(3));
		cus.setPincode(rs.getInt(4));
		cus.setEmail(rs.getString(5));
		cus.setContactNum(rs.getLong(6));
		cus.setCreateDate(rs.getDate(7));
		cus.setCreatedBy(rs.getString(8));
		cus.setModifiedDate(rs.getDate(9));
		return cus;
	
	    }

}
