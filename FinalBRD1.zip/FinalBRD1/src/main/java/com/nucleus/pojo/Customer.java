package com.nucleus.pojo;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

@Entity
@Table(name="CUSTOMER_HEMU")
    public class Customer extends BaseEntity
     {
	
private static final long serialVersionUID=1L;
	@NotNull(message="Pincode cannot be null")
	@NumberFormat(style=Style.NUMBER)
	@Column(length=6, nullable=false)

	private int pincode;
      @NotEmpty(message="Email cannot be null")
	   @Email 
   private String email;
	@NotNull(message="Contact number cannot be null")
	@NumberFormat(style=Style.NUMBER)
	@Column(length=10, nullable=false)
private long contactNum;
	@Temporal(TemporalType.DATE)
private Date createDate;
private String createdBy;
	@Temporal(TemporalType.DATE)
private Date modifiedDate;
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNum() {
		return contactNum;
	}
	public void setContactNum(long contactNum) {
		this.contactNum = contactNum;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreateDate()
	{
		return createDate;
	}
	
	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Override
	public String toString() {
		return "Customer [pincode=" + pincode + ", email=" + email + ", contactNum=" + contactNum + ", createDate="
				+ createDate + ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate + "]";
	}
	
	
	
}
