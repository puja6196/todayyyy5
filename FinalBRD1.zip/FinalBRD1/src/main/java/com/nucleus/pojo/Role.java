package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ROLE_HEMU")
public class Role {
	@Id
	private String ROLEID;
	private String ROLENAME;
	
	public String getROLEID() {
		return ROLEID;
	}
	public void setROLEID(String rOLEID) {
		ROLEID = rOLEID;
	}
	public String getROLENAME() {
		return ROLENAME;
	}
	public void setROLENAME(String rOLENAME) {
		ROLENAME = rOLENAME;
	}
	@Override
	public String toString() {
		return "Role [ROLEID=" + ROLEID + ", ROLENAME=" + ROLENAME + "]";
	}
	
	
}
