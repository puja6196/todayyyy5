package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

 @Entity
 @Table(name="USER_HEMU")
  public class User 
  {
     @Id
	 @NotNull
	private int USERID;
	@NotEmpty
	@Pattern(regexp="[A-Za-z ]*$")
	private String USERNAME;
	@NotEmpty
	private String PASSWORD;
	@NotEmpty@Size(max=1, min=1)
	private String ENABLED;
	
	private int roleid;
	
	public int getUSERID() 
	{
		return USERID;
	}
	public void setUSERID(int uSERID) {
		USERID = uSERID;
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	
	public String getENABLED() {
		return ENABLED;
	
	}
	
	public void setENABLED(String eNABLED) 
	
	{
		ENABLED = eNABLED;
	}
	
	public String toString() {
		return "User [USERID=" + USERID + ", USERNAME=" + USERNAME + ", PASSWORD=" + PASSWORD + ", ENABLED=" + ENABLED
				+ ", ROLEID=" + "]";
	}
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	
}
