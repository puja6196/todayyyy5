package com.nucleus.service;

import java.util.List;

import com.nucleus.pojo.Customer;

public interface ServiceCustomerI {
	public int addCustomer(Customer cust);
	public int isUniqueCustomer(String code);
	public Customer viewSingle(String code);
	public List<Customer> viewMultiple();
	public Customer updateCustomerCode(String code);
	public int updateCustomer(Customer cust);
	public int deleteCustomer(int code);
}
