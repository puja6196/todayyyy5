package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CustomerDaoI;
import com.nucleus.pojo.Customer;

@Service
public class ServiceCustomerImpl implements ServiceCustomerI
{
	@Autowired
	CustomerDaoI dao;
	
	@Transactional
	@Override
	public int addCustomer(Customer cust) {
		int result=dao.addCustomer(cust);
		return result;
	}
	@Transactional
	@Override
	public int isUniqueCustomer(String code) {
		int result=dao.isUniqueCustomer(code);
		return result;
	}
	@Transactional
	@Override
	public Customer viewSingle(String code) {
		Customer customer=dao.viewSingle(code);
		return customer;
	}
	@Transactional
	@Override
	public List<Customer> viewMultiple() {
		List<Customer> list=dao.viewMultiple();
		return list;
	}
	@Transactional
	@Override
	public Customer updateCustomerCode(String code) {
		Customer customer=dao.viewSingle(code);
		return customer;
	}
	@Transactional
	@Override
	public int updateCustomer(Customer cust) {
		int result=dao.updateCustomer(cust); 
		return result;
	}
	@Transactional
	@Override
	public int deleteCustomer(int code) {
		int result=dao.deleteCustomer(code);
		return result;
	}

}
