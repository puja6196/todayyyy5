package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.nucleus.dao.UserDaoI;
import com.nucleus.pojo.Role;
import com.nucleus.pojo.User;
import com.nucleus.utility.PasswordEncoder;


@Service
public class ServiceUserImpl implements ServiceUserI{
	
	@Autowired
	UserDaoI dao;
	@Transactional
	@Override
	public int addUser(int id) {
		int result=dao.addUser(id);
		return result;
	}
	@Transactional
	@Override
	public int addedUser(User user) {
		/*String pass=user.getPASSWORD();
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(pass);
		if(BCrypt.checkpw(pass, hashedPassword))
		{
			System.out.println("password true");
		}
		else
			System.out.println("password false");
		User user1=new User();
		user1.setENABLED(user.getENABLED());
		user1.setUSERID(user.getUSERID());
		user1.setUSERNAME(user.getUSERNAME());
		user1.setPASSWORD(hashedPassword);*/
		//user.setPASSWORD(PasswordEncoder.passwordEncoder(user.getPASSWORD()));
		int result=dao.addedUser(user);
		return result;
	}
	@Transactional
	@Override
	public List<User> viewUser() {
		List<User> list=dao.viewUser();
		return list;
	}
	@Transactional
	@Override
	public int updateUser(Role role, int userid) {
		int result=dao.updateUser(role, userid);
		return result;
	}

}
