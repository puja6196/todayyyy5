package com.nucleus.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


 
public class PasswordEncoder 

{
	@Autowired
	public static String passwordEncoder(String pwd){
		BCryptPasswordEncoder bcrypt=new BCryptPasswordEncoder(12);
		return bcrypt.encode(pwd);
	}
	
}