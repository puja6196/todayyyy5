package com.nucleus.spring_ws;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SOAPException, IOException
    {
        System.out.println( "Hello World!" );
        
        MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage soapMsg = factory.createMessage();
		SOAPPart part = soapMsg.getSOAPPart();

		MimeHeaders headers = soapMsg.getMimeHeaders();
		headers.setHeader("Content-Type", "application/soap+xml; charset=utf-8");
				
		SOAPEnvelope envelope = part.getEnvelope();
		SOAPHeader header = envelope.getHeader();
		header.setAttribute("Content-Type", "text/html");
		SOAPBody body = envelope.getBody();
		SOAPElement personElement = body.addChildElement("Person");
		
		SOAPElement demoElements = personElement.addChildElement("Demographics");
		SOAPElement fNameElement = demoElements.addChildElement("FirstName");
		fNameElement.setTextContent("Mark");

		SOAPElement lNameElement = demoElements.addChildElement("LastName");
		lNameElement.setTextContent("Watson");

		SOAPElement ageElement = demoElements.addChildElement("Age");
		ageElement.setTextContent("30");

		SOAPElement instElements = personElement.addChildElement("Institute");
		instElements.addTextNode("Oxford");
		
		SOAPElement cityElements = personElement.addChildElement("City");
		cityElements.addTextNode("London");
		
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        soapMsg.setProperty("Content-Type", "text/html");
        soapMsg.saveChanges();

        soapMsg.writeTo(System.out);
        
        // Send SOAP Message to SOAP Server
        SOAPMessage soapResponse = soapConnection.call(soapMsg, "http://N0518DEDP18.nucleussoftware.com:8080/");

        OutputStream bos = new ByteArrayOutputStream();
		soapResponse.writeTo(bos);
		System.out.println(bos);
    }
}
